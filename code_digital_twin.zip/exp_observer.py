"""E1/E2: observer accuracy (latent volume state and force) and force-map identification."""
import numpy as np, json, time, itertools
from observer import *
from sklearn.neural_network import MLPRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, WhiteKernel, ConstantKernel
from sklearn.preprocessing import PolynomialFeatures, StandardScaler

d = np.load("data/offline.npz")
D, cols, pid, mode = d["D"], list(d["cols"]), d["pid"], d["mode"]
c = {n: i for i, n in enumerate(cols)}
TR = pid <= 9; VA = (pid >= 10) & (pid <= 11); TE = pid >= 12
WASH = 50
res = {}


def flat(A, m):
    return A[m][:, WASH:].reshape(-1, A.shape[-1])


Y = D[..., [c["h1"], c["h2"], c["F"]]]

# ---------------- hyper-parameter search (validation pouches) ----------------
t0 = time.time()
U = build_inputs(D, cols, "full")
sub = np.where(TR)[0][::2]
hp = []
import os
HP_GRID = [] if os.path.exists("res/hp.json") else list(itertools.product([200, 400, 800], [1, 2, 4, 8], [1.0, 2.0, 4.0]))
for N, lam, alpha in HP_GRID:
    r = PhysResBatch(U.shape[-1], N, lam, alpha)
    Xtr = np.concatenate([r.run(U[sub]), U[sub]], -1); Xva = np.concatenate([r.run(U[VA]), U[VA]], -1)
    W = ridge(flat(Xtr, np.ones(len(sub), bool)), flat(Y[sub], np.ones(len(sub), bool)))
    P = predict(flat(Xva, np.ones(VA.sum(), bool)), W)
    yv = flat(Y[VA], np.ones(VA.sum(), bool))
    e = [nrmse(yv[:, j], P[:, j]) for j in range(3)]
    hp.append(dict(N=N, lamda=lam, alpha=alpha, nrmse_h=float(np.mean(e[:2])), nrmse_F=e[2]))
    print(hp[-1], f"{time.time()-t0:.0f}s", flush=True)
if HP_GRID:
    json.dump(hp, open("res/hp.json", "w"))
hp = json.load(open("res/hp.json"))
res["hp_search"] = hp
best = min(hp, key=lambda z: z["nrmse_h"])
res["best_hp"] = best
print("best", best)

# ---------------- model comparison on unseen pouches ----------------
def stream_fit(fn, idx, lam=1e-4, bs=25):
    G = None; n = 0
    for k in range(0, len(idx), bs):
        b = idx[k:k + bs]
        A = flat(fn(b), np.ones(len(b), bool)); A = np.c_[A, np.ones(len(A), np.float32)]
        y = flat(Y[b], np.ones(len(b), bool))
        if G is None:
            G = np.zeros((A.shape[1], A.shape[1])); R = np.zeros((A.shape[1], 3))
        G += (A.T @ A).astype(np.float64); R += (A.T @ y).astype(np.float64); n += len(A)
    G[np.diag_indices_from(G)] += lam * n; G[-1, -1] -= lam * n
    return np.linalg.solve(G, R)


def stream_pred(fn, idx, W, bs=25):
    out = []
    for k in range(0, len(idx), bs):
        b = idx[k:k + bs]; F = fn(b)
        out.append((np.c_[F.reshape(-1, F.shape[-1]), np.ones(F.shape[0] * F.shape[1], np.float32)] @ W).reshape(len(b), -1, 3))
    return np.concatenate(out)


TRi, TEi = np.where(TR)[0], np.where(TE)[0]


def evaluate(name, fn):
    W = stream_fit(fn, TRi)
    out = {}
    Pfull = stream_pred(fn, TEi, W)
    Pte = Pfull[:, WASH:].reshape(-1, 3)
    yt = flat(Y[TE], np.ones(TE.sum(), bool))
    mte = np.repeat(mode[TE], D.shape[1] - WASH)
    for mm in ["free", "con", "hold", "all"]:
        k = (mte == mm) if mm != "all" else np.ones(len(mte), bool)
        out[mm] = dict(nrmse_h=float(np.mean([nrmse(yt[k, j], Pte[k, j]) for j in range(2)])),
                       rmse_h=float(np.sqrt(np.mean((yt[k, :2] - Pte[k, :2]) ** 2))),
                       nrmse_F=nrmse(yt[k, 2], Pte[k, 2]) if mm != "free" else None,
                       rmse_F=float(np.sqrt(np.mean((yt[k, 2] - Pte[k, 2]) ** 2))))
    print(name, out["all"], flush=True)
    return out, W, Pfull


N, lam, alpha = best["N"], best["lamda"], best["alpha"]
models = {}
for var in ["full", "disp", "disp_I", "mocap"]:
    Uv = build_inputs(D, cols, var)
    r = PhysResBatch(Uv.shape[-1], N, lam, alpha)
    models[f"PhysRes-{var}"] = (lambda b, r=r, Uv=Uv: np.concatenate([r.run(Uv[b]), Uv[b]], -1))
esn = ESNBatch(U.shape[-1], N)
models["ESN-full"] = lambda b: np.concatenate([esn.run(U[b]), U[b]], -1)
models["TDL-full"] = lambda b: tapped_delay(U[b])
models["Inst-full"] = lambda b: U[b]
cmp, preds, Ws = {}, {}, {}
for k, f in models.items():
    cmp[k], Ws[k], preds[k] = evaluate(k, f)
res["observer_cmp"] = cmp

# save PhysRes-full observer (h + F readouts) for the controller
r = PhysResBatch(U.shape[-1], N, lam, alpha)   # same seed -> same W_in as PhysRes-full above
W = Ws["PhysRes-full"]
np.savez("res/observer.npz", Win=r.Win, W=W, N=N, lamda=lam, alpha=alpha)
# example traces on a constrained test trial for Fig. 3
te_idx = np.where(TE)[0]
Ph = preds["PhysRes-full"]
ex = [i for i, j in enumerate(te_idx) if mode[j] == "con"][1]
exf = [i for i, j in enumerate(te_idx) if mode[j] == "free"][0]
np.savez("res/obs_traces.npz", con_true=Y[te_idx[ex]], con_pred=Ph[ex], con_in=D[te_idx[ex]],
         free_true=Y[te_idx[exf]], free_pred=Ph[exf], free_in=D[te_idx[exf]], cols=np.array(cols))

# ---------------- force map f_F(x_hat, T, dT, I) ----------------
Ptr_all = stream_pred(models["PhysRes-full"], TRi, W)
del preds
Pte_all = Ph


def fm_feats(Dm, Pm, which):
    h = Pm[..., :2]
    Tp = Dm[..., [c["Tp1"], c["Tp2"]]]
    dT = np.zeros_like(Tp); dT[:, 10:] = (Tp[:, 10:] - Tp[:, :-10]) / 1.0   # 1-s causal slope
    I = Dm[..., [c["I"]]]
    parts = {"V": [h], "V+T": [h, Tp], "V+T+dT": [h, Tp, dT], "V+T+dT+I": [h, Tp, dT, I],
             "T+dT+I": [Tp, dT, I]}[which]
    return np.concatenate(parts, -1)


cm_tr = np.isin(mode[TR], ["con", "hold"]); cm_te = np.isin(mode[TE], ["con", "hold"])
ytr = D[TR][cm_tr][:, WASH:, c["F"]].reshape(-1)
yte = D[TE][cm_te][:, WASH:, c["F"]].reshape(-1)
fm = {}
rng = np.random.default_rng(0)
for which in ["V", "V+T", "V+T+dT", "V+T+dT+I", "T+dT+I"]:
    Xa = fm_feats(D[TR][cm_tr], Ptr_all[cm_tr], which)[:, WASH:].reshape(-1, 0 + fm_feats(D[TR][:1], Ptr_all[:1], which).shape[-1])
    Xb = fm_feats(D[TE][cm_te], Pte_all[cm_te], which)[:, WASH:].reshape(-1, Xa.shape[-1])
    sc = StandardScaler().fit(Xa); Xa_, Xb_ = sc.transform(Xa), sc.transform(Xb)
    pf = PolynomialFeatures(2, include_bias=False).fit(Xa_)
    Wq = ridge(pf.transform(Xa_), ytr[:, None], 1e-5)
    pq = predict(pf.transform(Xb_), Wq)[:, 0]
    sub = rng.choice(len(Xa_), 60000, replace=False)
    mlp = MLPRegressor(hidden_layer_sizes=(64, 64), max_iter=300, random_state=0, early_stopping=True).fit(Xa_[sub], ytr[sub])
    pm = mlp.predict(Xb_)
    sub2 = rng.choice(len(Xa_), 1500, replace=False)
    gp = GaussianProcessRegressor(ConstantKernel() * RBF(np.ones(Xa_.shape[1])) + WhiteKernel(1e-3),
                                  normalize_y=True, random_state=0).fit(Xa_[sub2], ytr[sub2])
    pg = gp.predict(Xb_)
    contact = yte > 0.05
    # heating vs cooling split (sign of measured temperature slope)
    dTb = fm_feats(D[TE][cm_te], Pte_all[cm_te], "V+T+dT")[:, WASH:, 4].reshape(-1)
    fm[which] = {}
    for nm, p in [("quad", pq), ("mlp", pm), ("gp", pg)]:
        p = np.maximum(p, 0)
        fm[which][nm] = dict(rmse=float(np.sqrt(np.mean((p - yte) ** 2))),
                             rmse_contact=float(np.sqrt(np.mean((p[contact] - yte[contact]) ** 2))),
                             rmse_heat=float(np.sqrt(np.mean((p[contact & (dTb > 0.05)] - yte[contact & (dTb > 0.05)]) ** 2))),
                             rmse_cool=float(np.sqrt(np.mean((p[contact & (dTb < -0.05)] - yte[contact & (dTb < -0.05)]) ** 2))),
                             nrmse=nrmse(yte, p))
    print(which, fm[which], flush=True)
    if which == "V+T+dT+I":
        np.savez("res/forcemap.npz", mean=sc.mean_, scale=sc.scale_, Wq=Wq)
res["forcemap"] = fm
# bootstrap CI over test trials for the V vs V+T+dT+I quad maps
json.dump(res, open("res/observer_results.json", "w"), indent=1)
print("done", time.time() - t0)
