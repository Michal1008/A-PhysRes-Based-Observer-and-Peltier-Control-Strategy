import numpy as np, json, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from control import fm_predict
plt.rcParams.update({"font.size": 8, "font.family": "DejaVu Sans", "axes.linewidth": 0.6, "lines.linewidth": 1.0, "savefig.dpi": 400})
CB = ["#0072B2", "#E69F00", "#009E73", "#D55E00", "#CC79A7", "#56B4E9"]
z = np.load("res/obs_traces.npz"); cols = list(z["cols"]); c = {n: i for i, n in enumerate(cols)}
fig, ax = plt.subplots(2, 2, figsize=(7.2, 3.8))
t = np.arange(z["free_true"].shape[0]) * 0.1
ax[0, 0].plot(t, z["free_true"][:, 0], color="k", label="ground truth")
ax[0, 0].plot(t, z["free_in"][:, c["s1"]], color=CB[1], lw=0.6, alpha=0.8, label="displacement proxy $s$")
ax[0, 0].plot(t, z["free_pred"][:, 0], color=CB[0], ls="--", label="PhysRes $\\hat h$")
ax[0, 0].set_ylabel("$h$ (mm)"); ax[0, 0].set_title("(a) Free expansion, unseen pouch", loc="left", fontsize=8)
ax[0, 0].legend(frameon=False, fontsize=6.5)
ax[1, 0].plot(t, z["free_in"][:, c["Tl1"]], color="k", label="liquid $T_l$ (true)")
ax[1, 0].plot(t, z["free_in"][:, c["Tp1"]], color=CB[3], label="pouch NTC $T_p$")
ax2 = ax[1, 0].twinx(); ax2.step(t, z["free_in"][:, c["u"]], color="0.6", lw=0.6, where="post"); ax2.set_ylabel("duty $u$", color="0.4")
ax[1, 0].set_ylabel("T (°C)"); ax[1, 0].set_xlabel("Time (s)"); ax[1, 0].legend(frameon=False, fontsize=6.5, loc="lower right")
D = z["con_in"]; Pm = z["con_pred"]
Tp = D[:, [c["Tp1"], c["Tp2"]]]; dT = np.zeros_like(Tp); dT[10:] = Tp[10:] - Tp[:-10]
Fh = fm_predict(Pm[:, :2], Tp, dT, D[:, [c["I"]]])
ax[0, 1].plot(t, z["con_true"][:, 0], color="k", label="ground truth")
ax[0, 1].plot(t, z["con_pred"][:, 0], color=CB[0], ls="--", label="PhysRes $\\hat h$")
ax[0, 1].set_title(f"(b) Constrained expansion ($k$ = {D[0, c['kobj']]:.1f} N/mm$^p$)", loc="left", fontsize=8)
ax[0, 1].set_ylabel("$h$ (mm)"); ax[0, 1].legend(frameon=False, fontsize=6.5)
ax[1, 1].plot(t, z["con_true"][:, 2], color="k", label="true force")
ax[1, 1].plot(t, Fh, color=CB[2], ls="--", label="$f_F(\\hat x, T_p, \\dot T_p, I)$")
ax[1, 1].plot(t, np.maximum(Pm[:, 2], 0), color=CB[4], lw=0.7, alpha=0.8, label="linear reservoir read-out")
ax[1, 1].set_ylabel("$F$ (N)"); ax[1, 1].set_xlabel("Time (s)"); ax[1, 1].legend(frameon=False, fontsize=6.5)
for a in ax.ravel(): a.spines[["top"]].set_visible(False)
plt.tight_layout(); plt.savefig("fig/fig3_observer.png"); plt.savefig("fig/fig3_observer.pdf")

R = json.load(open("res/observer_results.json"))
fm = R["forcemap"]; sets = ["V", "T+dT+I", "V+T", "V+T+dT", "V+T+dT+I"]
lab = ["$\\hat x$", "$T,\\dot T,I$", "$\\hat x,T$", "$\\hat x,T,\\dot T$", "$\\hat x,T,\\dot T,I$"]
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.3))
w = 0.26
for j, (m, nm) in enumerate([("quad", "quadratic ridge"), ("mlp", "MLP (64-64)"), ("gp", "GP (RBF)")]):
    ax[0].bar(np.arange(5) + (j - 1) * w, [fm[s][m]["rmse_contact"] for s in sets], w, color=CB[j], label=nm)
ax[0].set_xticks(range(5)); ax[0].set_xticklabels(lab, fontsize=7); ax[0].set_ylabel("Force RMSE in contact (N)")
ax[0].legend(frameon=False, fontsize=6.5); ax[0].set_title("(a) Force-map inputs (unseen pouches)", loc="left", fontsize=8)
q = [fm[s]["quad"] for s in sets]
ax[1].bar(np.arange(5) - 0.18, [x["rmse_heat"] for x in q], 0.36, color=CB[3], label="heating ($\\dot T_p>0$)")
ax[1].bar(np.arange(5) + 0.18, [x["rmse_cool"] for x in q], 0.36, color=CB[0], label="cooling ($\\dot T_p<0$)")
ax[1].set_xticks(range(5)); ax[1].set_xticklabels(lab, fontsize=7); ax[1].set_ylabel("RMSE (N)")
ax[1].legend(frameon=False, fontsize=6.5); ax[1].set_title("(b) Heating vs cooling (quadratic map)", loc="left", fontsize=8)
for a in ax: a.spines[["top", "right"]].set_visible(False)
plt.tight_layout(); plt.savefig("fig/fig4_forcemap.png"); plt.savefig("fig/fig4_forcemap.pdf")
print("ok")
