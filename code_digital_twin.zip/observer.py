"""Multimodal PhysRes observer.
Batched re-implementation of the hysteretic-reservoir update of the reference
PhysRes code (KawaharaLab/PhysRes, prc/model.py):
    x(t) = sigma_{lambda,alpha}( minmax_{[-1,1]}( u(t) W_in + x(t - tau) ) )
where sigma applies the logistic function and then shifts the neuron vector by
lambda positions (zero-filled), so the reservoir behaves as a nonlinear
cyclic delay line whose memory depth scales with N / lambda.
Also includes ESN and tapped-delay linear baselines and ridge read-outs."""
import numpy as np

# fixed physical normalisation ranges for the inputs (no data leakage)
RANGES = dict(s=(0.0, 6.0), Tp=(15.0, 85.0), Tj=(15.0, 100.0), I=(-0.6, 0.6),
              mk=(0.0, 6.0))


def scale(v, key):
    lo, hi = RANGES[key]
    return (v - lo) / (hi - lo)


def build_inputs(D, cols, variant="full"):
    """D: (B, L, C) logged trials -> reservoir inputs (B, L, M)."""
    c = {n: i for i, n in enumerate(cols)}
    s = scale(D[..., [c["s1"], c["s2"]]], "s")
    Tp = scale(D[..., [c["Tp1"], c["Tp2"]]], "Tp")
    Tj = scale(D[..., [c["Tj1"], c["Tj2"]]], "Tj")
    I = scale(D[..., [c["I"]]], "I")
    if variant == "full":          # displacement + temperatures + current
        return np.concatenate([s, Tp, Tj, I], -1)
    if variant == "disp":          # displacement proxy only (closest to original paper)
        return s
    if variant == "disp_I":        # displacement + current (no temperature)
        return np.concatenate([s, I], -1)
    if variant == "mocap":         # motion-capture height (centre marker z) only
        h = D[..., [c["h1"], c["h2"]]]
        return scale(h, "mk")
    raise ValueError(variant)


class PhysResBatch:
    def __init__(self, M, N=400, lamda=1, alpha=1.0, tau=1, x0=0.0, seed=42):
        rng = np.random.default_rng(seed)
        self.Win = rng.uniform(0, 0.5, size=(M, N))   # as in prc/model.py
        self.N, self.lamda, self.alpha, self.tau, self.x0 = N, lamda, alpha, tau, x0

    def _sigma(self, z):
        f = 1.0 / (1.0 + np.exp(-self.alpha * z))
        if self.lamda == 0:
            return f
        out = np.zeros_like(f)
        out[..., self.lamda:] = f[..., :-self.lamda]
        return out

    def step(self, x_prev, u):
        """one update for a batch: x_prev (B,N), u (B,M)."""
        op = u @ self.Win + x_prev
        mn = op.min(-1, keepdims=True); mx = op.max(-1, keepdims=True)
        op = 2.0 * (op - mn) / (mx - mn + 1e-12) - 1.0
        return self._sigma(op)

    def run(self, U):
        B, L, M = U.shape
        X = np.zeros((B, L, self.N), dtype=np.float32)
        X[:, :self.tau] = self.x0
        for t in range(self.tau, L):
            X[:, t] = self.step(X[:, t - self.tau], U[:, t])
        return X


class ESNBatch:
    def __init__(self, M, N=400, rho=0.9, leak=0.3, sin=1.0, seed=42):
        rng = np.random.default_rng(seed)
        W = rng.standard_normal((N, N)) * (rng.random((N, N)) < 0.05)
        W *= rho / np.max(np.abs(np.linalg.eigvals(W)))
        self.W, self.Win = W, rng.uniform(-sin, sin, size=(M, N))
        self.b = rng.uniform(-0.2, 0.2, N)
        self.N, self.leak = N, leak

    def step(self, x_prev, u):
        return (1 - self.leak) * x_prev + self.leak * np.tanh(u @ self.Win + x_prev @ self.W + self.b)

    def run(self, U):
        B, L, M = U.shape
        X = np.zeros((B, L, self.N), dtype=np.float32)
        for t in range(1, L):
            X[:, t] = self.step(X[:, t - 1], U[:, t])
        return X


def tapped_delay(U, lags=(0, 1, 2, 5, 10, 20, 50, 100)):
    """linear tapped-delay-line features (ARX-type baseline)."""
    B, L, M = U.shape
    out = []
    for l in lags:
        sh = np.zeros_like(U)
        sh[:, l:] = U[:, :L - l] if l > 0 else U
        out.append(sh)
    return np.concatenate(out, -1)


def ridge(Phi, Y, lam=1e-4):
    """ridge regression with bias; Phi (n,p), Y (n,q)."""
    A = np.c_[Phi, np.ones(len(Phi))].astype(np.float32)
    G = (A.T @ A).astype(np.float64)
    G[np.diag_indices_from(G)] += lam * len(A)
    G[-1, -1] -= lam * len(A)
    return np.linalg.solve(G, (A.T @ Y).astype(np.float64))


def predict(Phi, W):
    return np.c_[Phi, np.ones(len(Phi))] @ W


def nrmse(y, yh):
    return float(np.sqrt(np.mean((y - yh) ** 2) / np.var(y)))
