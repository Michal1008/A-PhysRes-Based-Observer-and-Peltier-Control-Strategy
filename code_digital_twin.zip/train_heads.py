"""Train the short-horizon prediction head (feedforward) and the move-blocked
multi-step heads used by the predictive controller, on top of the PhysRes
observer features.  Offline data, training pouches only."""
import numpy as np, json
from observer import *
from control import fm_predict

d = np.load("data/offline.npz")
D, cols, pid, mode = d["D"], list(d["cols"]), d["pid"], d["mode"]
c = {n: i for i, n in enumerate(cols)}
o = np.load("res/observer.npz")
N = int(o["N"])
r = PhysResBatch(o["Win"].shape[0], N, int(o["lamda"]), float(o["alpha"])); r.Win = o["Win"]
U = build_inputs(D, cols, "full")
WASH = 50


def features(idx):
    X = np.concatenate([r.run(U[idx]), U[idx]], -1)
    Y = predict(X.reshape(-1, X.shape[-1]), o["W"]).reshape(len(idx), -1, 3)
    h = Y[..., :2]
    Tp = D[idx][..., [c["Tp1"], c["Tp2"]]]
    dT = np.zeros_like(Tp); dT[:, 10:] = (Tp[:, 10:] - Tp[:, :-10]) / 1.0
    I = D[idx][..., c["I"]]
    Fhat = fm_predict(h, Tp, dT, I[..., None])
    Fm = D[idx][..., c["Fm"]]
    Tj = D[idx][..., [c["Tj1"], c["Tj2"]]]
    P = np.concatenate([np.ones_like(Fm)[..., None], Fm[..., None], Fhat[..., None], h,
                        (Tp - 50) / 20, dT, (I / 0.6)[..., None], (Tj - 50) / 20], -1)
    return P, D[idx][..., c["F"]], D[idx][..., c["u"]], Tp.max(-1)


def head_data(P, F, u, D_):
    L = P.shape[1]
    t = np.arange(WASH, L - D_)
    ub = np.stack([u[:, k:k + D_].mean(1) for k in t], 1)
    Pp = P[:, t]; y = F[:, t + D_]
    A = np.concatenate([Pp, Pp * ub[..., None]], -1)
    return A.reshape(-1, A.shape[-1]), y.reshape(-1), Pp.reshape(-1, Pp.shape[-1]), ub.reshape(-1)


TR = np.where(pid <= 9)[0]; TE = np.where(pid >= 12)[0]
Ptr, Ftr, utr, Ttr = features(TR)
Pte, Fte, ute, Tte = features(TE)
p = Ptr.shape[-1]
out = {}
heads = {}
for D_ in [10, 20, 30]:
    A, y, _, _ = head_data(Ptr, Ftr, utr, D_)
    G = A.T @ A + 1e-3 * len(A) * np.eye(A.shape[1]); th = np.linalg.solve(G, A.T @ y)
    At, yt, _, _ = head_data(Pte, Fte, ute, D_)
    pr = At @ th
    # persistence baseline: F(t+D) = F_meas(t)
    pers = head_data(Pte, Fte, ute, D_)[2][:, 1]
    out[f"head_D{D_}"] = dict(rmse=float(np.sqrt(np.mean((pr - yt) ** 2))),
                              rmse_persist=float(np.sqrt(np.mean((pers - yt) ** 2))))
    heads[D_] = th
    print(D_, out[f"head_D{D_}"], flush=True)
np.savez("res/head.npz", theta=heads[20][:p], w=heads[20][p:], D=20)

# ---- multi-step move-blocked heads (H blocks of 1 s) ----
H, BL = 4, 10


def mpc_data(P, F, u, T):
    L = P.shape[1]
    t = np.arange(WASH, L - H * BL)
    ub = np.stack([np.stack([u[:, k + j * BL:k + (j + 1) * BL].mean(1) for j in range(H)], -1) for k in t], 1)
    Pp = P[:, t]
    Fy = np.stack([F[:, t + (k + 1) * BL] for k in range(H)], -1)
    Ty = np.stack([T[:, t + (k + 1) * BL] for k in range(H)], -1)
    return Pp.reshape(-1, p), ub.reshape(-1, H), Fy.reshape(-1, H), Ty.reshape(-1, H)


Pp, ub, Fy, Ty = mpc_data(Ptr, Ftr, utr, Ttr)
A_ = np.zeros((H, p)); B_ = np.zeros((H, H, p)); AT = np.zeros((H, p)); BT = np.zeros((H, H, p))
Pq, ubq, Fq, Tq = mpc_data(Pte, Fte, ute, Tte)
mpc_err = []
for k in range(H):
    feats = np.concatenate([Pp] + [Pp * ub[:, [j]] for j in range(k + 1)], -1)
    G = feats.T @ feats + 1e-3 * len(feats) * np.eye(feats.shape[1])
    thF = np.linalg.solve(G, feats.T @ Fy[:, k]); thT = np.linalg.solve(G, feats.T @ Ty[:, k])
    A_[k] = thF[:p]; AT[k] = thT[:p]
    for j in range(k + 1):
        B_[k, j] = thF[p * (j + 1):p * (j + 2)]; BT[k, j] = thT[p * (j + 1):p * (j + 2)]
    fq = np.concatenate([Pq] + [Pq * ubq[:, [j]] for j in range(k + 1)], -1)
    mpc_err.append(dict(k=k + 1, rmse_F=float(np.sqrt(np.mean((fq @ thF - Fq[:, k]) ** 2))),
                        rmse_T=float(np.sqrt(np.mean((fq @ thT - Tq[:, k]) ** 2)))))
    print(mpc_err[-1], flush=True)
out["mpc_heads"] = mpc_err
np.savez("res/mpc.npz", A=A_, B=B_, AT=AT, BT=BT)
json.dump(out, open("res/heads_results.json", "w"), indent=1)
