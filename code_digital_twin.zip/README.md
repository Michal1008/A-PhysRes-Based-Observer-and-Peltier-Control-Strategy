# PhysRes volume-force-temperature control: digital-twin reproduction code

Order of execution (Python 3.13, numpy, scipy, scikit-learn, numba, matplotlib, tqdm):
1. `python datagen.py`        – offline multimodal data (free / constrained / holding), 16 virtual pouch pairs
2. `python exp_observer.py`   – PhysRes hyper-parameter search, observer comparison (Table 2), force map (Table 3)
3. `python train_heads.py`    – prediction head (Eq. 12) and move-blocked MPC heads
4. `python train_noT.py`      – temperature-free ablation pipeline
5. `python exp_control.py`    – gain tuning, step tracking, robustness grid, ablations, adaptation (Table 4)
6. `python exp_grasp.py`      – grasping with disturbances (Table 5)
7. `python exp_noT.py; python exp_extra.py; python exp_extra2.py` – ablation stats, sensor-free, thermal stress
8. `python fig_twin.py; python fig_arch.py; python fig_obs.py; python fig_control.py` – figures

Files: twin.py (physics model), observer.py (batched PhysRes = KawaharaLab/PhysRes update, ESN, TDL),
control.py (B1-B4 + governor + adaptation), sim.py (episode runner, metrics). prc/ and scripts/ are the
reference PhysRes package (KawaharaLab/PhysRes) used for the equivalence check.
All seeds fixed; results/ holds the JSON outputs quoted in the manuscript.
