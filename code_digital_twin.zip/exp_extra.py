"""E8: force-sensor-free operation (PhysRes soft sensor in the loop); E9: thermal-safety stress test."""
import numpy as np, json, itertools
from sim import *
from control import *
R = json.load(open("res/control_results.json"))
head = dict(np.load("res/head.npz")); b2, b3 = R["gains"]["B2"], R["gains"]["B3"]
c = R["B1_calib"]; umap = (np.array(c["F"]), np.array(c["u"]))

class Sensorless(PhysResFFPI):
    name = "B3-SL"
    def __call__(self, m, Fref, dt=0.02):
        m = dict(m); m["F"] = self.obs.F
        return super().__call__(m, Fref, dt)

out = {}
grid = list(itertools.product([20.0, 25.0, 30.0], ["soft", "medium", "hard"], [12, 13, 14, 15], [0, 1]))
for name, mk in [("B3-SL", lambda: Sensorless(head, Kp=b3[0], Ki=b3[1]))]:
    rs = []
    for Ta, ob, p, rep in grid:
        L = run_episode(mk(), BANK[p], Ta, OBJ[ob], seed=1000 * p + rep, gap_jitter=0.3)
        a, _ = episode_metrics(L); a.update(Ta=Ta, obj=ob, pouch=p, rep=rep); rs.append(a)
    out[name] = rs
    print(name, "ss %.3f iae %.1f OS %.1f unsettled %d" % (np.mean([r["ss_rmse"] for r in rs]), np.mean([r["iae"] for r in rs]),
          np.nanmean([r["overshoot"] for r in rs]), sum(r["unsettled"] for r in rs)), flush=True)
# thermal stress: demand 3.0 N from a soft object at 30 C
prof = lambda t: 0.0 if t < 1 else 3.0
st = {}
for name, mk in [("B2", lambda: PID(*b2)), ("B2-noGov", lambda: PID(*b2, gov=False)),
                 ("B3", lambda: PhysResFFPI(head, Kp=b3[0], Ki=b3[1])), ("B3-noGov", lambda: PhysResFFPI(head, Kp=b3[0], Ki=b3[1], gov=False))]:
    rs = []
    for p in [12, 13, 14, 15]:
        L = run_episode(mk(), BANK[p], 30.0, OBJ["soft"], profile=prof, T_end=120.0, seed=p)
        rs.append(dict(Tl_max=float(L["Tl"].max()), t_over=float(np.mean(L["Tl"] > T_MAX) * 100),
                       F_end=float(L["F"][-500:].mean())))
        if p == 12:
            np.savez(f"res/stress_{name}.npz", t=L["t"], F=L["F"], Tl=L["Tl"], u=L["u"])
    st[name] = rs
    print(name, rs, flush=True)
out["stress"] = st
json.dump(out, open("res/extra_results.json", "w"), indent=1, default=float)
