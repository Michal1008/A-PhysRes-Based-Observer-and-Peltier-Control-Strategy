import numpy as np, json, pickle, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.size": 8, "font.family": "DejaVu Sans", "axes.linewidth": 0.6, "lines.linewidth": 1.0, "savefig.dpi": 400})
COL = {"B1": "#999999", "B2": "#E69F00", "B3": "#0072B2", "B4": "#009E73"}
LAB = {"B1": "B1 open loop", "B2": "B2 PID", "B3": "B3 PhysRes FF+PI", "B4": "B4 PhysRes MPC"}
R = json.load(open("res/control_results.json"))

# ---- Fig 5: step tracking
T = pickle.load(open("res/traces_step.pkl", "rb"))
fig, ax = plt.subplots(3, 1, figsize=(7.2, 4.6), sharex=True, gridspec_kw=dict(height_ratios=[2, 1, 1]))
ax[0].plot(T["B3"]["t"], T["B3"]["Fref"], "k:", lw=0.9, label="$F_{ref}$")
for k in ["B1", "B2", "B3", "B4"]:
    L = T[k]
    ax[0].plot(L["t"], L["F"], color=COL[k], label=LAB[k], lw=0.9 if k != "B3" else 1.3)
    ax[1].plot(L["t"], L["u"], color=COL[k], lw=0.6)
    ax[2].plot(L["t"], L["Tl"], color=COL[k], lw=0.9)
ax[0].plot(T["B3"]["t"], T["B3"]["Fhat"], color="#56B4E9", lw=0.6, ls="--", label="B3 soft-sensor $\\hat F$")
ax[0].set_ylabel("Grip force (N)"); ax[0].legend(ncol=3, frameon=False, fontsize=6.5, loc="upper right")
ax[0].set_ylim(0, 2.6); ax[0].text(97, 2.45, "B1 off-scale", fontsize=6.3, color="#777")
ax[1].set_ylabel("Duty $u$"); ax[2].set_ylabel("$T_l$ (°C)"); ax[2].set_xlabel("Time (s)")
ax[2].axhline(75, color="r", lw=0.6, ls="--"); ax[2].text(2, 72.5, "$T_{max}$", color="r", fontsize=6.5)
for a in ax: a.spines[["top", "right"]].set_visible(False)
plt.tight_layout(); plt.savefig("fig/fig5_step.png"); plt.savefig("fig/fig5_step.pdf"); plt.close()

# ---- Fig 6: robustness grid
rob = R["robust"]
fig, ax = plt.subplots(1, 3, figsize=(7.2, 2.4))
names = ["B2", "B3", "B4"]
for j, (met, yl) in enumerate([("iae", "IAE per episode (N s)"), ("overshoot", "Mean overshoot (%)"), ("settle", "Mean settling time (s)")]):
    for i, k in enumerate(names):
        for a, Ta in enumerate([20.0, 25.0, 30.0]):
            v = [r[met] for r in rob[k] if r["Ta"] == Ta]
            ax[j].bar(a + (i - 1) * 0.26, np.nanmean(v), 0.26, color=COL[k], yerr=np.nanstd(v), capsize=1.5,
                      error_kw=dict(lw=0.5), label=LAB[k] if a == 0 else None)
    ax[j].set_xticks(range(3)); ax[j].set_xticklabels(["20 °C", "25 °C", "30 °C"]); ax[j].set_ylabel(yl)
    ax[j].spines[["top", "right"]].set_visible(False)
fig.legend(*ax[0].get_legend_handles_labels(), loc="upper center", ncol=3, frameon=False, fontsize=7)
plt.tight_layout(rect=(0, 0, 1, 0.92)); plt.savefig("fig/fig6_robust.png"); plt.savefig("fig/fig6_robust.pdf"); plt.close()

# ---- Fig 7: disturbance traces + grasp success
E = pickle.load(open("res/traces_dist.pkl", "rb"))
G = json.load(open("res/grasp_results.json"))
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.5), gridspec_kw=dict(width_ratios=[1.3, 1]))
for k in ["B1", "B2", "B3", "B4"]:
    L = E[k]; m = (L["t"] > 30) & (L["t"] < 70)
    ax[0].plot(L["t"][m], L["F"][m], color=COL[k], label=LAB[k])
ax[0].axvline(40, color="k", lw=0.5, ls=":"); ax[0].text(40.4, 1.5, "lateral impulse", fontsize=6.5); ax[0].set_ylim(0.3, 1.62)
b1 = E["B1"]["F"][(E["B1"]["t"] > 30) & (E["B1"]["t"] < 70)].mean(); ax[0].text(30.5, 1.52, f"B1 off-scale (mean {b1:.1f} N)", fontsize=6.3, color="#777")
ax[0].axhline(1.0, color="k", lw=0.5, ls="--")
ax[0].set_xlabel("Time (s)"); ax[0].set_ylabel("Grip force (N)"); ax[0].legend(frameon=False, fontsize=6.3)
ax[0].set_title("(a) Medium silicone, 30 °C, unseen pouch", loc="left", fontsize=8)
objs = list(G["B1"].keys())
for i, k in enumerate(["B1", "B2", "B3", "B4"]):
    ax[1].bar(np.arange(len(objs)) + (i - 1.5) * 0.2, [100 * G[k][o]["success"] for o in objs], 0.2, color=COL[k], label=LAB[k])
ax[1].set_xticks(range(len(objs))); ax[1].set_xticklabels([o.replace("silicone-", "sil.\n") for o in objs], fontsize=6.5)
ax[1].set_ylabel("Grasp success (%)"); ax[1].set_title("(b) Success over 24 trials/object", loc="left", fontsize=8)
for a in ax: a.spines[["top", "right"]].set_visible(False)
plt.tight_layout(); plt.savefig("fig/fig7_grasp.png"); plt.savefig("fig/fig7_grasp.pdf"); plt.close()

# ---- Fig 8: adaptation
A = R["adapt"]
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.3))
for mode, c, lab in [("fixed", "#999999", "fixed read-out"), ("adapt", "#0072B2", "between-grasp re-fit")]:
    iae = np.array([[g["iae"] for g in cur] for cur in A[mode]]); fh = np.array([[g["os"] for g in cur] for cur in A[mode]])
    x = np.arange(1, iae.shape[1] + 1)
    ax[0].errorbar(x, iae.mean(0), iae.std(0), color=c, marker="o", ms=3, capsize=2, lw=1, label=lab)
    ax[1].errorbar(x, fh.mean(0), fh.std(0), color=c, marker="o", ms=3, capsize=2, lw=1, label=lab)
ax[0].set_xlabel("Grasp index"); ax[0].set_ylabel("IAE (N s)"); ax[1].set_xlabel("Grasp index"); ax[1].set_ylabel("Mean overshoot (%)")
ax[0].legend(frameon=False, fontsize=6.5)
for a in ax: a.spines[["top", "right"]].set_visible(False)
plt.tight_layout(); plt.savefig("fig/fig8_adapt.png"); plt.savefig("fig/fig8_adapt.pdf"); plt.close()
print("figs ok")
