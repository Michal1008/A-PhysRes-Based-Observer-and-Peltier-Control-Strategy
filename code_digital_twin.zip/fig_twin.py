import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from twin import *
plt.rcParams.update({"font.size": 8, "font.family": "DejaVu Sans", "axes.linewidth": 0.6,
                     "lines.linewidth": 1.1, "savefig.dpi": 400})
CB = ["#0072B2", "#E69F00", "#009E73", "#D55E00", "#CC79A7", "#56B4E9"]
P = np.stack([make_pouch(), make_pouch()])
fig, ax = plt.subplots(1, 3, figsize=(7.2, 2.3))
# (a) free inflation for different heating times, then active cooling
res = {}
for i, ton in enumerate([10, 20, 30, 40]):
    g = Gripper(P, Ta=298.15, sensor_noise=False); t = []; h = []; T = []
    for k in range(int(60 / 0.02)):
        tt = k * 0.02; g.step(1.0 if tt < ton else -1.0)
        tr = g.truth(); t.append(tt); h.append(tr["h"][0]); T.append(tr["Tl"][0])
    ax[0].plot(t, h, color=CB[i], label=f"$t_{{on}}$ = {ton} s")
    res[ton] = (np.array(t), np.array(h), np.array(T))
ax[0].set_xlabel("Time (s)"); ax[0].set_ylabel("Cap height $h$ (mm)"); ax[0].legend(frameon=False, fontsize=6.5)
ax[0].set_title("(a) Free inflation", fontsize=8, loc="left")
# (b) h vs liquid temperature: heating/cooling hysteresis for t_on = 30 s
t, h, T = res[30]
ax[1].plot(T[t < 30], h[t < 30], color=CB[3], label="heating")
ax[1].plot(T[t >= 30], h[t >= 30], color=CB[0], label="cooling")
ax[1].axvline(61, color="0.6", ls=":", lw=0.8); ax[1].text(61.5, 0.3, "$T_b$ = 61 °C", fontsize=6.5, color="0.4")
ax[1].set_xlabel("Liquid temperature $T_l$ (°C)"); ax[1].set_ylabel("$h$ (mm)"); ax[1].legend(frameon=False, fontsize=6.5)
ax[1].set_title("(b) Volume–temperature loop", fontsize=8, loc="left")
# (c) constrained: force vs cap height for heating and cooling at two stiffnesses
for j, (k, lab) in enumerate([(0.8, "soft"), (8.0, "hard")]):
    g = Gripper(P, Ta=298.15, kobj=k, pobj=1.2, gap=0.8, sensor_noise=False); F = []; hh = []; ph = []; TT = []
    for kk in range(int(70 / 0.02)):
        tt = kk * 0.02; u = 0.9 if tt < 40 else -1.0
        g.step(u); tr = g.truth(); F.append(tr["F"]); hh.append(tr["h"].mean()); TT.append(tr["Tl"].mean()); ph.append(tt < 40)
    F, hh, ph, TT = map(np.array, (F, hh, ph, TT))
    ax[2].plot(TT[ph], F[ph], color=CB[3 if j == 0 else 1], ls="-", label=f"{lab}, heating")
    ax[2].plot(TT[~ph], F[~ph], color=CB[0 if j == 0 else 2], ls="--", label=f"{lab}, cooling")
ax[2].set_xlabel("Liquid temperature $T_l$ (°C)"); ax[2].set_ylabel("Grip force $F$ (N)")
ax[2].legend(frameon=False, fontsize=6); ax[2].set_title("(c) Constrained force", fontsize=8, loc="left")
for a in ax: a.spines[["top", "right"]].set_visible(False)
plt.tight_layout(); plt.savefig("fig/fig1_twin.png"); plt.savefig("fig/fig2_twin.pdf")
print("ok")
