"""Re-train the full observer/force-map/head pipeline WITHOUT temperature
channels (ablation 'no temperature input'), same hyper-parameters."""
import numpy as np, json
from observer import *
from control import poly2
from sklearn.preprocessing import StandardScaler

d = np.load("data/offline.npz")
D, cols, pid, mode = d["D"], list(d["cols"]), d["pid"], d["mode"]
c = {n: i for i, n in enumerate(cols)}
o = np.load("res/observer.npz"); N, lam, alpha = int(o["N"]), int(o["lamda"]), float(o["alpha"])
U = build_inputs(D, cols, "disp_I")
r = PhysResBatch(U.shape[-1], N, lam, alpha)
Y = D[..., [c["h1"], c["h2"], c["F"]]]
WASH = 50
TR = np.where(pid <= 9)[0]; TE = np.where(pid >= 12)[0]


def feats(b):
    return np.concatenate([r.run(U[b]), U[b]], -1)


G = None; n = 0
for k in range(0, len(TR), 25):
    b = TR[k:k + 25]; A = feats(b)[:, WASH:].reshape(-1, N + U.shape[-1])
    A = np.c_[A, np.ones(len(A), np.float32)]; y = Y[b][:, WASH:].reshape(-1, 3)
    if G is None:
        G = np.zeros((A.shape[1],) * 2); Rr = np.zeros((A.shape[1], 3))
    G += A.T @ A; Rr += A.T @ y; n += len(A)
G[np.diag_indices_from(G)] += 1e-4 * n; G[-1, -1] -= 1e-4 * n
W = np.linalg.solve(G, Rr)
np.savez("res/noT_observer.npz", Win=r.Win, W=W, N=N, lamda=lam, alpha=alpha)


def preds(idx):
    out = []
    for k in range(0, len(idx), 25):
        b = idx[k:k + 25]; F = feats(b)
        out.append((np.c_[F.reshape(-1, F.shape[-1]), np.ones(F.shape[0] * F.shape[1])] @ W).reshape(len(b), -1, 3))
    return np.concatenate(out)


Ptr, Pte = preds(TR), preds(TE)
# force map on [h_hat, I]
def Z(Dm, Pm):
    return np.concatenate([Pm[..., :2], Dm[..., [c["I"]]]], -1)
cm = np.isin(mode[TR], ["con", "hold"]); cmt = np.isin(mode[TE], ["con", "hold"])
Za = Z(D[TR][cm], Ptr[cm])[:, WASH:].reshape(-1, 3); ya = D[TR][cm][:, WASH:, c["F"]].reshape(-1)
sc = StandardScaler().fit(Za)
Wq = ridge(poly2(sc.transform(Za)), ya[:, None], 1e-5)
np.savez("res/noT_forcemap.npz", mean=sc.mean_, scale=sc.scale_, Wq=Wq)
Zb = Z(D[TE][cmt], Pte[cmt])[:, WASH:].reshape(-1, 3); yb = D[TE][cmt][:, WASH:, c["F"]].reshape(-1)
pb = np.maximum(predict(poly2(sc.transform(Zb)), Wq)[:, 0], 0)
out = dict(fm_rmse=float(np.sqrt(np.mean((pb - yb) ** 2))))


# head (D = 2 s) with temperature-free features
def Pfeat(idx, P):
    h = P[..., :2]; I = D[idx][..., c["I"]]
    Fh = np.maximum(predict(poly2(sc.transform(np.concatenate([h, I[..., None]], -1).reshape(-1, 3))), Wq)[:, 0], 0).reshape(I.shape)
    Fm = D[idx][..., c["Fm"]]
    return np.concatenate([np.ones_like(Fm)[..., None], Fm[..., None], Fh[..., None], h, (I / 0.6)[..., None]], -1)


def hd(Pf, idx, D_=20):
    F = D[idx][..., c["F"]]; u = D[idx][..., c["u"]]
    t = np.arange(WASH, Pf.shape[1] - D_)
    ub = np.stack([u[:, k:k + D_].mean(1) for k in t], 1)
    Pp = Pf[:, t]
    return np.concatenate([Pp, Pp * ub[..., None]], -1).reshape(-1, 2 * Pf.shape[-1]), F[:, t + D_].reshape(-1)


A, y = hd(Pfeat(TR, Ptr), TR)
th = np.linalg.solve(A.T @ A + 1e-3 * len(A) * np.eye(A.shape[1]), A.T @ y)
At, yt = hd(Pfeat(TE, Pte), TE)
out["head_rmse"] = float(np.sqrt(np.mean((At @ th - yt) ** 2)))
p = A.shape[1] // 2
np.savez("res/noT_head.npz", theta=th[:p], w=th[p:], D=20)
json.dump(out, open("res/noT_results.json", "w"), indent=1)
print(out)
