"""Episode runner and metrics for closed-loop force control on the twin."""
import numpy as np, time
from twin import Gripper
from datagen import pouch_bank

BANK = pouch_bank()
OBJ = dict(soft=(0.8, 1.2, 0.8), medium=(2.5, 1.2, 0.8), hard=(8.0, 1.2, 0.8))


def step_profile(t):
    return 0.8 if t < 40 else (1.5 if t < 80 else (0.5 if t < 120 else 1.0))


STEP_EDGES = [0, 40, 80, 120, 160]


def run_episode(ctrl, P, Ta_C=25.0, obj=(2.5, 1.2, 0.8), profile=step_profile, T_end=160.0,
                seed=0, dist=None, gap_jitter=0.0):
    rng = np.random.default_rng(seed)
    k, p, gap = obj
    gap = gap + gap_jitter * rng.uniform(-1, 1)
    g = Gripper(P, Ta=Ta_C + 273.15, kobj=k, pobj=p, gap=gap, seed=seed)
    n = int(T_end / g.DT)
    L = dict(t=np.zeros(n), Fref=np.zeros(n), F=np.zeros(n), Fm=np.zeros(n), u=np.zeros(n),
             Tl=np.zeros(n), Tp=np.zeros(n), h=np.zeros(n), Fhat=np.full(n, np.nan))
    tc = np.zeros(n)
    for i in range(n):
        t = i * g.DT
        if dist is not None:
            dist(g, t, gap)
        m = g.meas()
        Fr = profile(t)
        t0 = time.perf_counter(); u = ctrl(m, Fr); tc[i] = time.perf_counter() - t0
        g.step(u)
        tr = g.truth()
        L["t"][i] = t + g.DT; L["Fref"][i] = Fr; L["F"][i] = tr["F"]; L["Fm"][i] = m["F"]; L["u"][i] = u
        L["Tl"][i] = tr["Tl"].max(); L["Tp"][i] = m["Tp"].max(); L["h"][i] = tr["h"].mean()
        if hasattr(ctrl, "obs"):
            L["Fhat"][i] = ctrl.obs.F
    L["tc"] = tc
    return L


def seg_metrics(L, t0, t1, band_rel=0.10, band_abs=0.05):
    m = (L["t"] > t0 + 1e-6) & (L["t"] <= t1 + 1e-6)
    t, F, Fr = L["t"][m] - t0, L["F"][m], L["Fref"][m]
    r = Fr[-1]; f0 = F[0] if t0 > 0 else 0.0
    band = max(band_rel * r, band_abs)
    stepsz = r - f0
    out = {}
    # rise time 10-90 % of the step
    if abs(stepsz) > 1e-6:
        prog = (F - f0) / stepsz
        i10 = np.argmax(prog >= 0.1) if (prog >= 0.1).any() else None
        i90 = np.argmax(prog >= 0.9) if (prog >= 0.9).any() else None
        out["rise"] = float(t[i90] - t[i10]) if (i10 is not None and i90 is not None) else np.nan
        out["t90"] = float(t[i90]) if i90 is not None else np.nan
        over = (F - r) / abs(stepsz) if stepsz > 0 else (r - F) / abs(stepsz)
        out["overshoot"] = float(max(0.0, over.max()) * 100)
    out["peak"] = float(F.max())
    outside = np.where(np.abs(F - r) > band)[0]
    out["settle"] = float(t[outside[-1]]) if len(outside) and outside[-1] < len(t) - 1 else (np.nan if len(outside) else 0.0)
    if len(outside) and outside[-1] == len(t) - 1:
        out["settle"] = np.nan
    ss = t > (t[-1] - 15.0)
    out["ss_rmse"] = float(np.sqrt(np.mean((F[ss] - r) ** 2)))
    out["iae"] = float(np.trapezoid(np.abs(F - Fr), t))
    return out


def episode_metrics(L, edges=STEP_EDGES):
    segs = [seg_metrics(L, a, b) for a, b in zip(edges[:-1], edges[1:])]
    agg = dict(
        ss_rmse=float(np.mean([s["ss_rmse"] for s in segs])),
        overshoot=float(np.nanmean([s.get("overshoot", np.nan) for s in segs])),
        rise=float(np.nanmean([s.get("rise", np.nan) for s in segs])),
        settle=float(np.nanmean([s["settle"] for s in segs])) if not np.all(np.isnan([s["settle"] for s in segs])) else np.nan,
        unsettled=int(np.sum(np.isnan([s["settle"] for s in segs]))),
        iae=float(sum(s["iae"] for s in segs)),
        Tl_max=float(L["Tl"].max()), Tp_max=float(L["Tp"].max()),
        t_over=float(np.mean(L["Tl"] > 75.0) * 100),
        tc_mean=float(L["tc"].mean() * 1e3), tc_p99=float(np.percentile(L["tc"], 99) * 1e3))
    return agg, segs
