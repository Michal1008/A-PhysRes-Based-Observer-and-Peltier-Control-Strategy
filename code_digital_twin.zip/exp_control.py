"""E3-E7: calibration/tuning of baselines, step tracking, robustness grid,
grasping with disturbances, ablations, online adaptation, timing."""
import numpy as np, json, time, itertools, sys, pickle
from sim import *
from control import *
from twin import make_pouch, Gripper
from scipy.stats import wilcoxon

head = dict(np.load("res/head.npz")); mpc = dict(np.load("res/mpc.npz"))
R = {}
t00 = time.time()
TUNE_POUCH = [0, 1, 2]
TEST_POUCH = [12, 13, 14, 15]


def tune_dist(g, t, gap0):   # object shift during tuning (same for every controller)
    if 60.0 <= t < 60.02:
        g.gap = gap0 + 0.15


def cost(L):
    agg, segs = episode_metrics(L)
    return agg["iae"] + 0.1 * agg["overshoot"] + 20 * agg["unsettled"]


# ---------------- B1 calibration (nominal pouch, 25 C, medium object) ----------------
Pnom = np.stack([make_pouch(), make_pouch()])


def steady_force(u, obj=OBJ["medium"], T=150.0):
    g = Gripper(Pnom, Ta=298.15, kobj=obj[0], pobj=obj[1], gap=obj[2], sensor_noise=False)
    for _ in range(int(T / g.DT)):
        g.step(u)
    return g.truth()["F"]


Fgrid = np.array([0.1, 0.2, 0.3, 0.5, 0.8, 1.0, 1.5, 2.0, 2.5])
ugrid = []
for Fr in Fgrid:
    lo, hi = 0.6, 1.0
    for _ in range(12):
        mid = 0.5 * (lo + hi)
        if steady_force(mid) < Fr:
            lo = mid
        else:
            hi = mid
    ugrid.append(0.5 * (lo + hi))
umap = (Fgrid, np.array(ugrid))
best_b = None
for tb in [8, 10, 12, 14, 16, 18, 20, 24]:
    L = run_episode(OpenLoop(umap, tb), Pnom, 25.0, OBJ["medium"], seed=1)
    c_ = cost(L)
    if best_b is None or c_ < best_b[1]:
        best_b = (tb, c_)
R["B1_calib"] = dict(F=Fgrid.tolist(), u=list(map(float, ugrid)), t_burst=best_b[0])
print("B1 calib", R["B1_calib"], f"{time.time()-t00:.0f}s", flush=True)

# ---------------- gain tuning on training pouches (equal budget) ----------------
def tune(make, grid):
    res = []
    for g in grid:
        c_ = np.mean([cost(run_episode(make(*g), BANK[p], 25.0, OBJ["medium"], seed=p, dist=tune_dist)) for p in TUNE_POUCH])
        res.append((c_, g))
    res.sort(key=lambda z: z[0])
    return res[0][1], res


b2, r2 = tune(lambda kp, ki, kd: PID(kp, ki, kd), list(itertools.product([0.3, 0.6, 1.0, 1.5, 2.5], [0.02, 0.05, 0.1, 0.2], [0.0, 0.3])))
print("B2 gains", b2, r2[:3], f"{time.time()-t00:.0f}s", flush=True)
b3, r3 = tune(lambda kp, ki: PhysResFFPI(head, Kp=kp, Ki=ki), list(itertools.product([0.1, 0.2, 0.3, 0.6, 1.0, 1.5], [0.01, 0.03, 0.05, 0.1, 0.2])))
print("B3 gains", b3, r3[:3], f"{time.time()-t00:.0f}s", flush=True)
b4, r4 = tune(lambda lam, kp, ki: PhysResMPC(head, mpc, lam=lam, Kp=kp, Ki=ki),
              list(itertools.product([0.005, 0.02, 0.1], [0.1, 0.3, 0.6, 1.0], [0.01, 0.05, 0.2])))
print("B4 gains", b4, r4[:3], f"{time.time()-t00:.0f}s", flush=True)
R["gains"] = dict(B2=b2, B3=b3, B4=b4)

CTRL = {
    "B1": lambda: OpenLoop(umap, best_b[0]),
    "B2": lambda: PID(*b2),
    "B3": lambda: PhysResFFPI(head, Kp=b3[0], Ki=b3[1]),
    "B4": lambda: PhysResMPC(head, mpc, lam=b4[0], Kp=b4[1], Ki=b4[2]),
    # ablations
    "B3-noT": lambda: PhysResFFPI(dict(np.load("res/noT_head.npz")), Kp=b3[0], Ki=b3[1], obs_variant="noT"),
    "B3-noFF": lambda: PhysResFFPI(head, Kp=b3[0], Ki=b3[1], use_ff=False),
    "B3-noGov": lambda: PhysResFFPI(head, Kp=b3[0], Ki=b3[1], gov=False),
}

# ---------------- E3: nominal step tracking traces (unseen pouch 12) ----------------
traces = {}
for k in ["B1", "B2", "B3", "B4"]:
    traces[k] = run_episode(CTRL[k](), BANK[12], 25.0, OBJ["medium"], seed=12)
pickle.dump(traces, open("res/traces_step.pkl", "wb"))

# ---------------- E4: robustness grid ----------------
grid = list(itertools.product([20.0, 25.0, 30.0], ["soft", "medium", "hard"], TEST_POUCH, [0, 1]))
rob = {k: [] for k in CTRL}
for name in CTRL:
    for Ta, ob, p, rep in grid:
        L = run_episode(CTRL[name](), BANK[p], Ta, OBJ[ob], seed=1000 * p + rep, gap_jitter=0.3)
        agg, segs = episode_metrics(L)
        agg.update(Ta=Ta, obj=ob, pouch=p, rep=rep)
        rob[name].append(agg)
    a = rob[name]
    print(name, "ssRMSE %.3f OS %.1f settle %.1f unsettled %d Tmax %.1f tc %.3f ms" % (
        np.mean([x["ss_rmse"] for x in a]), np.nanmean([x["overshoot"] for x in a]),
        np.nanmean([x["settle"] for x in a]), sum(x["unsettled"] for x in a),
        np.max([x["Tl_max"] for x in a]), np.mean([x["tc_mean"] for x in a])), f"{time.time()-t00:.0f}s", flush=True)
R["robust"] = rob

# paired statistics (Wilcoxon signed-rank on per-episode IAE and ss-RMSE)
stats = {}
for a, b in [("B3", "B1"), ("B3", "B2"), ("B4", "B3"), ("B4", "B2"), ("B3", "B3-noT"), ("B3", "B3-noFF")]:
    for met in ["iae", "ss_rmse", "overshoot"]:
        x = np.array([r[met] for r in rob[a]]); y = np.array([r[met] for r in rob[b]])
        ok = ~(np.isnan(x) | np.isnan(y))
        try:
            p = float(wilcoxon(x[ok], y[ok]).pvalue)
        except ValueError:
            p = float("nan")
        stats[f"{a}_vs_{b}_{met}"] = dict(med_a=float(np.median(x[ok])), med_b=float(np.median(y[ok])), p=p)
R["stats"] = stats
json.dump(R, open("res/control_results.json", "w"), indent=1, default=float)

# ---------------- E6: online adaptation (30 C, unseen pouches, 8 successive grasps) ----------------
ad = {}
prof = lambda t: 0.0 if t < 2 else (1.2 if t < 50 else 0.6)
for mode_ in ["fixed", "adapt"]:
    curves = []
    for p in TEST_POUCH:
        ctrl = PhysResFFPI(head, Kp=b3[0], Ki=b3[1], adapt=(mode_ == "adapt"))
        errs = []
        for gi in range(8):
            ctrl.obs = RTObserver(); ctrl.i = 0.0; ctrl.k = 0; ctrl.buf = []; ctrl.bias = 0.0; ctrl.ulog = []
            L = run_episode(ctrl, BANK[p], 30.0, OBJ["medium"], profile=prof, T_end=90.0, seed=300 + gi)
            agg, segs = episode_metrics(L, edges=[2, 50, 90])
            fpe = np.nanmean(np.abs(L["Fhat"] - L["F"])[L["t"] > 10])
            errs.append(dict(iae=agg["iae"], os=agg["overshoot"], fhat_mae=float(fpe)))
            if mode_ == "adapt":
                ctrl.readapt()
        curves.append(errs)
    ad[mode_] = curves
    print("adapt", mode_, [np.mean([c[g]["iae"] for c in curves]) for g in range(8)], flush=True)
R["adapt"] = ad

# ---------------- E7: compute cost ----------------
o = np.load("res/observer.npz"); N = int(o["N"]); M = o["Win"].shape[0]
R["compute"] = dict(N=N, M=M, physres_flops=2 * M * N + 6 * N, esn_flops_5pct=2 * M * N + 2 * int(0.05 * N * N) + 4 * N,
                    readout_flops=2 * (N + M + 1) * 3)
json.dump(R, open("res/control_results.json", "w"), indent=1, default=float)
print("ALL DONE", time.time() - t00)
