"""
Lumped-parameter digital twin of a dual liquid phase-change pouch gripper
driven by bidirectional (H-bridge) Peltier modules.

Physics per pouch i (two pouches face each other across the object):
  * Peltier stack (4 modules in series): Seebeck pumping, Joule heating, conduction.
  * Three thermal nodes: Peltier pouch-side junction T_h, liquid/film T_l, Peltier
    back side/mount T_s.
  * Liquid-vapour phase change of Noah 7100 (HFE-type, Tb = 61 C) driven by the
    departure of vapour partial pressure from Clausius-Clapeyron saturation, with
    liquid-pooling-dependent evaporation and slower condensation.
  * Quasi-inextensible nylon/LDPE film: cap volume V = Vd + a_v h (a_v from the
    rounded-square frustum of Caremel et al., one-sided cap), soft elastic
    pressure with strain stiffening near h_max, Dahl-type film hysteresis.
  * Contact with an object of stiffness k_obj (power law), squeezed by both pouches.
Sensors: displacement proxy (Hall), NTCs, current sensor, load cell, optional
"motion-capture" ground truth.  All units SI unless stated (h in mm, F in N).
"""
import numpy as np
from numba import njit

R_GAS = 8.314
P_ATM = 101325.0
T_B = 334.15            # boiling point of Noah 7100 at 1 atm [K]
L_MOL = 28000.0         # latent heat [J/mol] (112 kJ/kg * 0.25 kg/mol)
A_V = 4.609e-7          # m^3 per mm cap height (one-sided rounded-square frustum)

# parameter vector layout (per pouch)
PNAMES = ["S", "Rp", "Kp", "Ch", "Cl", "Cs", "Ghl", "Gla", "Gha", "Gsa",
          "ntot", "nair", "Vd", "hmax", "pe1", "pe2", "kap", "kcond",
          "phys", "hd", "Ac0", "ch", "s_gain", "s_off", "Tl_off"]
PIDX = {n: i for i, n in enumerate(PNAMES)}

NOMINAL = dict(
    S=0.014, Rp=6.0, Kp=0.05,            # Peltier stack (4 in series): V/K, ohm, W/K
    Ch=0.30, Cl=0.15, Cs=0.9,            # J/K
    Ghl=0.05, Gla=0.015, Gha=0.015, Gsa=0.055,   # W/K
    ntot=1.208e-4, nair=4.1e-6,          # mol (0.02 mL Noah 7100 = 30.2 mg)
    Vd=1.0e-7, hmax=5.0,                 # m^3, mm
    pe1=800.0, pe2=30000.0,              # Pa
    kap=2.4e-9, kcond=0.55,              # mol/(Pa s), condensation ratio
    phys=1500.0, hd=0.3,                 # Pa, mm (film hysteresis)
    Ac0=2.0e-4, ch=0.15,                 # m^2, N s/mm
    s_gain=1.0, s_off=0.0, Tl_off=0.0)   # sensor calibration errors


def make_pouch(rng=None, spread=1.0):
    """Draw one pouch parameter vector with fabrication variability."""
    p = np.array([NOMINAL[n] for n in PNAMES], dtype=np.float64)
    if rng is None:
        return p
    rel = dict(S=0.05, Rp=0.05, Kp=0.08, Ch=0.10, Cl=0.10, Cs=0.10, Ghl=0.15,
               Gla=0.15, Gha=0.15, Gsa=0.10, ntot=0.08, nair=0.30, Vd=0.20,
               hmax=0.05, pe1=0.20, pe2=0.15, kap=0.20, kcond=0.10, phys=0.25,
               hd=0.20, Ac0=0.06, ch=0.15)
    for n, r in rel.items():
        p[PIDX[n]] *= max(0.3, 1.0 + spread * r * rng.standard_normal())
    p[PIDX["s_gain"]] = 1.0 + spread * 0.03 * rng.standard_normal()
    p[PIDX["s_off"]] = spread * 0.05 * rng.standard_normal()
    p[PIDX["Tl_off"]] = spread * 0.3 * rng.standard_normal()
    return p


@njit(cache=True)
def psat(T):
    return P_ATM * np.exp(-(L_MOL / R_GAS) * (1.0 / T - 1.0 / T_B))


@njit(cache=True)
def _elastic(h, hmax, pe1, pe2):
    r = h / hmax
    return pe1 * r + pe2 * r ** 8


@njit(cache=True)
def step_gripper(X, P, I_cmd, Ta, kobj, pobj, gap, dt_ctrl, n_sub):
    """Advance the two-pouch gripper by one control period.
    X: (2, 8) state [Th, Tl, Ts, nv, h, z, F_contact(shared, stored in both), unused]
    P: (2, npar) parameters; I_cmd: current command [A] (same H-bridge command, both pouches)
    Returns mean electrical power over the period."""
    dt = dt_ctrl / n_sub
    pw = 0.0
    for _ in range(n_sub):
        # contact force from current cap heights
        delta = (X[0, 4] - gap) + (X[1, 4] - gap)
        if kobj > 0.0 and delta > 0.0:
            F = kobj * delta ** pobj
        else:
            F = 0.0
        for i in range(2):
            S = P[i, 0]; Rp = P[i, 1]; Kp = P[i, 2]
            Ch = P[i, 3]; Cl = P[i, 4]; Cs = P[i, 5]
            Ghl = P[i, 6]; Gla = P[i, 7]; Gha = P[i, 8]; Gsa = P[i, 9]
            ntot = P[i, 10]; nair = P[i, 11]; Vd = P[i, 12]; hmax = P[i, 13]
            pe1 = P[i, 14]; pe2 = P[i, 15]; kap = P[i, 16]; kcond = P[i, 17]
            phys = P[i, 18]; hd = P[i, 19]; Ac0 = P[i, 20]; ch = P[i, 21]
            Th = X[i, 0]; Tl = X[i, 1]; Ts = X[i, 2]; nv = X[i, 3]; h = X[i, 4]; z = X[i, 5]
            # current through stack, limited by supply incl. Seebeck back-EMF
            I = I_cmd
            # Peltier heat flows
            Qh = S * I * Th + 0.5 * Rp * I * I - Kp * (Th - Ts)
            Qs = -S * I * Ts + 0.5 * Rp * I * I + Kp * (Th - Ts)
            pw += (S * I * (Th - Ts) + Rp * I * I) / (2.0 * n_sub)
            # gas / phase change
            V = Vd + A_V * h
            nl = ntot - nv
            Pv = nv * R_GAS * Tl / V
            Pt = (nv + nair) * R_GAS * Tl / V
            dP = psat(Tl) - Pv
            if dP > 0.0:
                phi = (nl / ntot) ** 0.5 if nl > 0.0 else 0.0
                ndot = kap * phi * dP
                if ndot * dt > nl:
                    ndot = nl / dt
            else:
                ndot = kcond * kap * dP
                if -ndot * dt > nv:
                    ndot = -nv / dt
            # thermal nodes
            dTh = (Qh - Ghl * (Th - Tl) - Gha * (Th - Ta)) / Ch
            dTl = (Ghl * (Th - Tl) - Gla * (Tl - Ta) - L_MOL * ndot) / Cl
            dTs = (Qs - Gsa * (Ts - Ta)) / Cs
            # membrane mechanics (quasi-static with small damping)
            Ac = Ac0 * (0.5 + 0.5 * min(1.0, h / hmax))
            net = Ac * (Pt - P_ATM - _elastic(h, hmax, pe1, pe2) - phys * z) - F
            hdot = net / ch
            if h <= 0.0 and hdot < 0.0:
                hdot = 0.0
            sgn = 1.0 if hdot >= 0.0 else -1.0
            dz = (hdot / hd) * (1.0 - z * sgn)
            X[i, 0] = Th + dt * dTh
            X[i, 1] = Tl + dt * dTl
            X[i, 2] = Ts + dt * dTs
            X[i, 3] = nv + dt * ndot
            X[i, 4] = max(0.0, h + dt * hdot)
            zn = z + dt * dz
            X[i, 5] = min(1.0, max(-1.0, zn))
        delta = (X[0, 4] - gap) + (X[1, 4] - gap)
        X[0, 6] = kobj * delta ** pobj if (kobj > 0.0 and delta > 0.0) else 0.0
        X[1, 6] = X[0, 6]
    return pw




def equilibrium_state(P, Ta):
    """Rest state at ambient: vapour in equilibrium at Ta, cap balanced."""
    X = np.zeros((2, 8))
    for i in range(2):
        T = Ta
        X[i, 0:3] = T
        # solve for nv,h with Pv = psat(Ta) and force balance (free, no contact)
        Ps = P_ATM * np.exp(-(L_MOL / R_GAS) * (1.0 / T - 1.0 / T_B))
        hmax, pe1, pe2, Vd, nair = P[i, 13], P[i, 14], P[i, 15], P[i, 12], P[i, 11]
        lo, hi = 0.0, hmax * 1.3
        for _ in range(60):
            h = 0.5 * (lo + hi)
            V = Vd + A_V * h
            Pt = Ps + nair * R_GAS * T / V
            res = Pt - P_ATM - (pe1 * h / hmax + pe2 * (h / hmax) ** 8)
            if res > 0:
                lo = h
            else:
                hi = h
        V = Vd + A_V * h
        X[i, 3] = min(Ps * V / (R_GAS * T), 0.95 * P[i, 10])
        X[i, 4] = h
    return X


class Gripper:
    """Gripper + sensors. Control period 20 ms (50 Hz)."""
    DT = 0.02

    def __init__(self, P, Ta=298.15, kobj=0.0, pobj=1.0, gap=0.8, seed=0,
                 n_sub=20, sensor_noise=True):
        self.P = np.ascontiguousarray(P, dtype=np.float64)
        self.Ta = Ta
        self.kobj, self.pobj, self.gap = kobj, pobj, gap
        self.rng = np.random.default_rng(seed)
        self.n_sub = n_sub
        self.noise = 1.0 if sensor_noise else 0.0
        self.X = equilibrium_state(self.P, Ta)
        self.Tl_m = np.array([Ta, Ta]) + self.P[:, PIDX["Tl_off"]]
        self.Th_m = np.array([Ta, Ta])
        self.F_m = 0.0
        self.t = 0.0
        self.I = 0.0

    def set_object(self, kobj, pobj, gap):
        self.kobj, self.pobj, self.gap = kobj, pobj, gap

    I_MAX = 0.6   # A, 3.7 V supply across a 6-ohm stack

    def step(self, u_cmd):
        """u_cmd in [-1, 1]: signed H-bridge duty (current-loop set-point / I_MAX)."""
        I = float(np.clip(u_cmd, -1.0, 1.0)) * self.I_MAX
        I_act = I + 0.003 * self.noise * self.rng.standard_normal()  # current-loop ripple
        self.I = I
        pw = step_gripper(self.X, self.P, I_act, self.Ta, self.kobj, self.pobj,
                          self.gap, self.DT, self.n_sub)
        self.t += self.DT
        a1 = self.DT / 1.2   # pouch NTC lag 1.2 s
        a2 = self.DT / 0.4   # Peltier NTC lag 0.4 s
        self.Tl_m += a1 * (self.X[:, 1] + self.P[:, PIDX["Tl_off"]] - self.Tl_m)
        self.Th_m += a2 * (self.X[:, 0] - self.Th_m)
        self.F_m += (self.DT / (self.DT + 0.01)) * (self.X[0, 6] - self.F_m)
        return pw

    # ---- measurements -------------------------------------------------
    def meas(self):
        n = self.noise * self.rng.standard_normal(8)
        h = self.X[:, 4]
        Tl = self.X[:, 1]
        s = (self.P[:, PIDX["s_gain"]] * h * (1 + 0.03 * h / self.P[:, PIDX["hmax"]])
             + self.P[:, PIDX["s_off"]] + 0.004 * (Tl - 298.15) + 0.02 * n[0:2])
        return dict(
            s=s,                                    # displacement proxy [mm]
            Tp=self.Tl_m - 273.15 + 0.08 * n[2:4],  # pouch NTC [C]
            Tj=self.Th_m - 273.15 + 0.08 * n[4:6],  # Peltier NTC [C]
            I=self.I + 0.003 * n[6],                # current sensor [A]
            F=max(0.0, self.F_m + 0.005 * n[7]),    # finger load cell [N]
        )

    def truth(self):
        return dict(h=self.X[:, 4].copy(), F=float(self.X[0, 6]),
                    Tl=self.X[:, 1] - 273.15, Th=self.X[:, 0] - 273.15,
                    V=(self.P[:, PIDX["Vd"]] + A_V * self.X[:, 4]) * 1e6,
                    liq=1 - self.X[:, 3] / self.P[:, PIDX["ntot"]])

    def markers(self):
        """Synthetic 5-marker motion-capture coordinates (pouch 0), mm."""
        h = self.X[0, 4]
        c = np.array([[-10, -10, 0], [10, -10, 0], [0, 0, h], [10, 10, 0], [-10, 10, 0]], float)
        c[2, 0] += 0.04 * h  # slight asymmetric bulge
        return c + 0.01 * self.noise * self.rng.standard_normal(c.shape)
