import numpy as np
from sim import *
from control import *
head=dict(np.load("res/head.npz"))
L=run_episode(PhysResFFPI(head),BANK[12],25.0,OBJ["medium"])
for t in range(30,90,2):
    i=int(t/0.02)-1; print(t, f"Fr={L['Fref'][i]:.2f} F={L['F'][i]:.2f} Fm={L['Fm'][i]:.2f} Fh={L['Fhat'][i]:.2f} u={L['u'][i]:.2f} Tl={L['Tl'][i]:.1f} h={L['h'][i]:.2f}")
