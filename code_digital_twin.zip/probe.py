import numpy as np, time
from observer import *
d=np.load("data/offline.npz"); D,cols,pid,mode=d["D"],list(d["cols"]),d["pid"],d["mode"]
c={n:i for i,n in enumerate(cols)}
TR=pid<=9; VA=(pid>=10)&(pid<=11); W=50
Y=D[...,[c["h1"],c["h2"],c["F"]]]
U=build_inputs(D,cols,"full")
sub=np.where(TR)[0][::2]
def fl(A): return A[:,W:].reshape(-1,A.shape[-1])
def ev(name,ftr,fva):
    Wt=ridge(fl(ftr),fl(Y[sub])); P=predict(fl(fva),Wt); yv=fl(Y[VA])
    con=np.isin(np.repeat(mode[VA],D.shape[1]-W),["con","hold"])
    print(f"{name:40s} h {np.mean([nrmse(yv[:,j],P[:,j]) for j in range(2)]):.4f}  F(con) {nrmse(yv[con,2],P[con,2]):.4f}",flush=True)
groups=[[0,1],[2,3],[4,5],[6]]
for N,lam,al in [(400,4,2.0),(400,4,4.0),(400,8,4.0),(400,8,8.0),(400,16,4.0)]:
    r=PhysResBatch(7,N,lam,al); ev(f"single N{N} l{lam} a{al}",r.run(U[sub]),r.run(U[VA]))
    ev(f"single+in N{N} l{lam} a{al}",np.concatenate([r.run(U[sub]),U[sub]],-1),np.concatenate([r.run(U[VA]),U[VA]],-1))
    rs=[PhysResBatch(len(g),N//4,lam,al,seed=42+i) for i,g in enumerate(groups)]
    Xa=np.concatenate([rr.run(U[sub][...,g]) for rr,g in zip(rs,groups)]+[U[sub]],-1)
    Xb=np.concatenate([rr.run(U[VA][...,g]) for rr,g in zip(rs,groups)]+[U[VA]],-1)
    ev(f"modal+in N{N} l{lam} a{al}",Xa,Xb)
e=ESNBatch(7,400); ev("ESN+in",np.concatenate([e.run(U[sub]),U[sub]],-1),np.concatenate([e.run(U[VA]),U[VA]],-1))
