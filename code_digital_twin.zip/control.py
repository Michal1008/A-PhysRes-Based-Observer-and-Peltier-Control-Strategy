"""Controllers for the liquid-pouch gripper.
B1 open-loop preset thermal cycle, B2 PID on the load cell,
B3 PhysRes feedforward + PI feedback (+ temperature governor),
B4 PhysRes predictive control (move-blocked, bounded least squares).
The PhysRes observer runs at 10 Hz (every 5th 50-Hz tick)."""
import numpy as np
from scipy.optimize import lsq_linear
from observer import PhysResBatch, RANGES, scale

T_MAX = 75.0      # pouch-surface temperature limit [C]
DEC = 5
_FM = {}


def poly2(Z):
    d = Z.shape[-1]
    cross = [Z[..., i] * Z[..., j] for i in range(d) for j in range(i, d)]
    return np.concatenate([Z, np.stack(cross, -1)], -1)


def fm_predict(h, Tp, dT, I, path="res/forcemap.npz", useT=True):
    """static volume-force-temperature map F = f_F(x_hat, T, dT/dt, I) (quadratic ridge)."""
    if path not in _FM:
        _FM[path] = dict(np.load(path))
    fm = _FM[path]
    Z = np.concatenate([h, Tp, dT, I], -1) if useT else np.concatenate([h, I], -1)
    Q = poly2((Z - fm["mean"]) / fm["scale"])
    F = Q @ fm["Wq"][:-1, 0] + fm["Wq"][-1, 0]
    return np.maximum(F, 0.0)


PROFILES = {"full": dict(obs="res/observer.npz", fm="res/forcemap.npz", useT=True),
            "noT": dict(obs="res/noT_observer.npz", fm="res/noT_forcemap.npz", useT=False)}


class RTObserver:
    """Real-time multimodal PhysRes observer (single gripper)."""

    def __init__(self, path=None, variant="full"):
        self.prof = PROFILES[variant]; self.useT = self.prof["useT"]
        o = np.load(path or self.prof["obs"])
        self.N = int(o["N"])
        self.r = PhysResBatch(o["Win"].shape[0], self.N, int(o["lamda"]), float(o["alpha"]))
        self.r.Win = o["Win"]; self.W = o["W"]
        self.x = np.zeros((1, self.N)); self.variant = variant
        self.Tbuf = []
        self.h = np.zeros(2); self.F = 0.0; self.dT = np.zeros(2)

    def inp(self, m):
        if self.variant == "full":
            return np.r_[scale(m["s"], "s"), scale(m["Tp"], "Tp"), scale(m["Tj"], "Tj"), scale(np.r_[m["I"]], "I")]
        if self.variant == "noT":   # re-trained observer without temperature channels
            return np.r_[scale(m["s"], "s"), scale(np.r_[m["I"]], "I")]
        raise ValueError

    def update(self, m):
        self.u_last = self.inp(m)
        self.x = self.r.step(self.x, self.u_last[None])
        y = np.r_[self.x[0], self.u_last, 1.0] @ self.W
        self.h, self.F = y[:2], max(0.0, float(y[2]))
        self.Tbuf.append(m["Tp"].copy())
        if len(self.Tbuf) > 11:
            self.Tbuf.pop(0)
        self.dT = (self.Tbuf[-1] - self.Tbuf[0]) / (0.1 * (len(self.Tbuf) - 1)) if len(self.Tbuf) > 1 else np.zeros(2)
        self.F = float(fm_predict(self.h, m["Tp"], self.dT, np.r_[m["I"]], self.prof["fm"], self.useT))
        return self.h, self.F


def phi(obs, m, n_pc=None):
    """compact feature vector for the predictive heads."""
    if not obs.useT:
        return np.r_[1.0, m["F"], obs.F, obs.h, m["I"] / 0.6]
    return np.r_[1.0, m["F"], obs.F, obs.h, (m["Tp"] - 50) / 20, obs.dT, m["I"] / 0.6,
                 (m["Tj"] - 50) / 20]


class Governor:
    """temperature safety: lag-compensated pouch temperature vs T_MAX."""

    def __init__(self, Tmax=T_MAX, band=3.0):
        self.Tmax, self.band = Tmax, band
        self.active = False

    def __call__(self, u, Tp, dT):
        Tpred = float(np.max(Tp + 1.2 * dT))
        self.active = False
        if Tpred > self.Tmax:
            self.active = True
            return min(u, -0.5)
        if Tpred > self.Tmax - self.band:
            self.active = True
            return min(u, (self.Tmax - Tpred) / self.band)
        return u


class OpenLoop:
    name = "B1"

    def __init__(self, umap, t_burst=18.0):
        self.umap, self.t_burst = umap, t_burst   # umap: F_ref -> holding duty
        self.t = 0.0; self.Fprev = None; self.burst_end = 0.0; self.cool_end = 0.0

    def __call__(self, m, Fref, dt=0.02):
        if self.Fprev is None or Fref != self.Fprev:
            if self.Fprev is None or Fref > self.Fprev:
                self.burst_end = self.t + (self.t_burst if self.Fprev is None else 6.0)
            else:
                self.cool_end = self.t + 4.0
            self.Fprev = Fref
        self.t += dt
        if Fref <= 0:
            return -1.0
        if self.t < self.burst_end:
            return 1.0
        if self.t < self.cool_end:
            return -0.6
        return float(np.interp(Fref, *self.umap))


class PID:
    name = "B2"

    def __init__(self, Kp=0.6, Ki=0.05, Kd=0.0, gov=True):
        self.Kp, self.Ki, self.Kd = Kp, Ki, Kd
        self.i = 0.0; self.eprev = None; self.gov = Governor() if gov else None
        self.Tb = []

    def __call__(self, m, Fref, dt=0.02):
        e = Fref - m["F"]
        de = 0.0 if self.eprev is None else (e - self.eprev) / dt
        self.eprev = e
        u = self.Kp * e + self.i + self.Kd * de
        if Fref <= 0:
            self.i = 0.0; u = -1.0
        elif -1 < u < 1 or (u >= 1 and e < 0) or (u <= -1 and e > 0):
            self.i += self.Ki * e * dt
        if self.gov:
            self.Tb.append(m["Tp"].copy()); self.Tb = self.Tb[-51:]
            dT = (self.Tb[-1] - self.Tb[0]) / (dt * (len(self.Tb) - 1)) if len(self.Tb) > 1 else 0 * m["Tp"]
            u = self.gov(u, m["Tp"], dT)
        return float(np.clip(u, -1, 1))


class PhysResFFPI:
    """B3: learned inverse (prediction head) feedforward + PI on force error."""
    name = "B3"

    def __init__(self, head, Kp=0.3, Ki=0.03, obs_variant="full", use_ff=True,
                 gov=True, adapt=False, obs_path=None):
        self.obs = RTObserver(obs_path, obs_variant); self.obs_variant = obs_variant
        self.theta, self.w = head["theta"].copy(), head["w"].copy()   # F(t+D) = th.phi + (w.phi) * ubar
        self.D = int(head["D"])                                    # horizon in 10-Hz ticks
        self.Kp, self.Ki = Kp, Ki
        self.i = 0.0; self.k = 0; self.uff = 0.0; self.use_ff = use_ff
        self.gov = Governor() if gov else None
        self.bias = 0.0; self.hist = []; self.adapt = adapt
        self.buf = []   # (phi, F_pred) history for bias estimation / adaptation
        self.ulog = []

    U_APP, T_APP = 0.80, 58.0   # boiling-aware approach: full heat until T_hat >= T_b - 3 K

    def approach(self, m):
        That = float(np.max(m["Tp"] + 1.2 * self.obs.dT))
        return 1.0 if That < self.T_APP else self.U_APP

    def ff(self, p, Fref, m=None):
        g = float(self.w @ p)
        base = float(self.theta @ p) + self.bias
        if g < 0.05:
            if Fref > base:
                return self.approach(m) if m is not None else 1.0
            return -1.0
        return float(np.clip((Fref - base) / g, -1, 1))

    def __call__(self, m, Fref, dt=0.02):
        if self.k % DEC == 0:
            self.obs.update(m)
            p = phi(self.obs, m)
            # realised outcome of a prediction made D ticks ago -> bias + data for adaptation
            self.buf.append([p, None, None])
            if len(self.buf) > self.D:
                p0, ub0, fp0 = self.buf[-self.D - 1]
                if fp0 is not None:
                    self.bias += 0.05 * (m["F"] - fp0 - self.bias)
                    if self.adapt:
                        self.hist.append((p0, ub0, m["F"]))
            if self.use_ff:
                self.uff = self.ff(p, Fref, m) if Fref > 0 else -1.0
            self.p = p
        self.k += 1
        e = Fref - m["F"]
        u = (self.uff if self.use_ff else 0.0) + self.Kp * e + self.i
        if Fref <= 0:
            self.i = 0.0; u = -1.0
        elif -1 < u < 1 or (u >= 1 and e < 0) or (u <= -1 and e > 0):
            self.i += self.Ki * e * dt
        if self.gov:
            u = self.gov(u, m["Tp"], self.obs.dT)
        u = float(np.clip(u, -1, 1))
        self.ulog.append(u)
        # store mean applied u over the last D ticks with the prediction made D ticks ago
        if self.k % DEC == 0 and len(self.buf) > 0:
            self.buf[-1][2] = float(self.theta @ self.buf[-1][0] + self.w @ self.buf[-1][0] * np.mean(self.ulog[-DEC:]))
            self.buf[-1][1] = float(np.mean(self.ulog[-DEC:]))
            if len(self.buf) > 4 * self.D:
                self.buf.pop(0)
        return u

    def readapt(self, gamma=50.0):
        """between-grasp batch re-fit of the head (reservoir fixed)."""
        if len(self.hist) < 50:
            return
        P = np.array([h[0] for h in self.hist]); ub = np.array([h[1] for h in self.hist])
        y = np.array([h[2] for h in self.hist])
        A = np.c_[P, P * ub[:, None]]
        th0 = np.r_[self.theta, self.w]
        G = A.T @ A + gamma * np.eye(A.shape[1])
        th = np.linalg.solve(G, A.T @ y + gamma * th0)
        self.theta, self.w = th[:P.shape[1]], th[P.shape[1]:]
        self.hist = []; self.bias = 0.0


class PhysResMPC(PhysResFFPI):
    """B4: move-blocked predictive control on the PhysRes latent features."""
    name = "B4"

    def __init__(self, head, mpc, lam=0.02, rho_T=5.0, **kw):
        super().__init__(head, **kw)
        self.A, self.B = mpc["A"], mpc["B"]        # F_k = A_k.phi + sum_j<=k (B_kj.phi) u_j
        self.AT, self.BT = mpc["AT"], mpc["BT"]    # same for max pouch temperature
        self.H = self.A.shape[0]; self.lam, self.rho = lam, rho_T
        self.uprev = 0.0; self.useq = np.zeros(self.H)

    def __call__(self, m, Fref, dt=0.02):
        if self.k % DEC == 0:
            self.obs.update(m)
            p = phi(self.obs, m)
            self.buf.append([p, None, None])
            if len(self.buf) > 10:
                p0, _, fp0 = self.buf[-11]
                if fp0 is not None:
                    self.bias += 0.05 * (m["F"] - fp0 - self.bias)
            if Fref <= 0:
                self.useq[:] = -1.0
            elif m["F"] < 0.03 and Fref > 0.05:     # contact-seeking phase: no force gradient yet
                self.useq[:] = self.approach(m)
            else:
                H = self.H
                G = np.zeros((H, H)); f0 = np.zeros(H); GT = np.zeros((H, H)); t0 = np.zeros(H)
                for k in range(H):
                    f0[k] = self.A[k] @ p + self.bias; t0[k] = self.AT[k] @ p
                    for j in range(k + 1):
                        G[k, j] = self.B[k, j] @ p; GT[k, j] = self.BT[k, j] @ p
                D = np.eye(H) - np.eye(H, k=-1)
                rows = [G, np.sqrt(self.lam) * D]
                rhs = [Fref - f0, np.sqrt(self.lam) * np.r_[self.uprev, np.zeros(H - 1)]]
                sol = lsq_linear(np.vstack(rows), np.concatenate(rhs), bounds=(-1, 1))
                Tpred = t0 + GT @ sol.x
                viol = Tpred > T_MAX - 2.0
                if viol.any():   # add soft temperature penalty rows and resolve
                    rows.append(np.sqrt(self.rho) * GT[viol]); rhs.append(np.sqrt(self.rho) * (T_MAX - 2.0 - t0[viol]))
                    sol = lsq_linear(np.vstack(rows), np.concatenate(rhs), bounds=(-1, 1))
                self.useq = sol.x
            self.uprev = float(self.useq[0])
            self.buf[-1][2] = float(self.A[0] @ p + sum(self.B[0, j] @ p * self.useq[j] for j in range(1)))
        self.k += 1
        e = Fref - m["F"]
        u = float(self.useq[0]) + (self.Kp * e + self.i if Fref > 0 else 0.0)
        if Fref > 0 and (-1 < u < 1):
            self.i += self.Ki * e * dt
        if self.gov:
            u = self.gov(u, m["Tp"], self.obs.dT)
        return float(np.clip(u, -1, 1))
