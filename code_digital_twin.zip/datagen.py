"""Offline multimodal data collection on the digital twin (Section 3 protocol).
Modes: 'free' (free expansion), 'con' (constrained expansion on a spring of
random stiffness), 'hold' (constant-force holding with a simple PI on the load
cell). Logged at 10 Hz (every 5th 50-Hz control tick)."""
import numpy as np, time, sys
from twin import Gripper, make_pouch

DEC = 5          # 50 Hz -> 10 Hz logging
T_TRIAL = 120.0  # s


def pouch_bank(n=16, seed=7):
    rng = np.random.default_rng(seed)
    return [np.stack([make_pouch(rng), make_pouch(rng)]) for _ in range(n)]


def random_excitation(rng, T=T_TRIAL, dt=0.02):
    u = np.zeros(int(T / dt))
    k = 0
    while k < len(u):
        ton = rng.integers(1, 41); a = rng.uniform(0.6, 1.0)
        u[k:k + int(ton / dt)] = a; k += int(ton / dt)
        toff = rng.integers(5, 16); b = rng.choice([0.0, rng.uniform(-1.0, -0.2)])
        u[k:k + int(toff / dt)] = b; k += int(toff / dt)
    return u


def sample_object(rng):
    k = float(np.exp(rng.uniform(np.log(0.5), np.log(10.0))))
    return k, float(rng.uniform(1.0, 1.4)), float(rng.uniform(0.3, 1.2))


def run_trial(P, mode, Ta, rng, seed):
    if mode == "free":
        kobj, pobj, gap = 0.0, 1.0, 1.0
    else:
        kobj, pobj, gap = sample_object(rng)
    g = Gripper(P, Ta=Ta, kobj=kobj, pobj=pobj, gap=gap, seed=seed)
    n = int(T_TRIAL / g.DT)
    if mode in ("free", "con"):
        u = random_excitation(rng)
    rows = []
    # hold mode: PI towards random force targets, with excitation dither
    Fref, integ, nxt = 0.0, 0.0, 0
    for k in range(n):
        m = g.meas()
        if mode == "hold":
            if k >= nxt:
                Fref = rng.uniform(0.2, 2.5); nxt = k + int(rng.uniform(15, 40) / g.DT)
            e = Fref - m["F"]
            uk = 0.80 + 0.25 * e + integ
            if -1 < uk < 1:
                integ += 0.004 * e
            uk = float(np.clip(uk + 0.05 * rng.standard_normal(), -1, 1))
        else:
            uk = u[k]
        g.step(uk)
        if k % DEC == DEC - 1:
            m = g.meas(); tr = g.truth()
            rows.append(np.r_[m["s"], m["Tp"], m["Tj"], m["I"], m["F"],
                              tr["h"], tr["F"], tr["Tl"], uk, kobj, pobj, gap, Ta - 273.15])
    return np.array(rows, dtype=np.float32)


COLS = ["s1", "s2", "Tp1", "Tp2", "Tj1", "Tj2", "I", "Fm", "h1", "h2", "F", "Tl1", "Tl2",
        "u", "kobj", "pobj", "gap", "Ta"]


def main(n_per_mode=120, out="data/offline.npz"):
    bank = pouch_bank()
    rng = np.random.default_rng(2026)
    D, meta = [], []
    t0 = time.time()
    for mode in ("free", "con", "hold"):
        for j in range(n_per_mode):
            pid = j % len(bank)
            Ta = 273.15 + rng.choice([20.0, 25.0, 30.0]) + rng.uniform(-0.5, 0.5)
            D.append(run_trial(bank[pid], mode, Ta, rng, seed=10000 + len(D)))
            meta.append((mode, pid, Ta - 273.15))
        print(mode, "done", time.time() - t0, flush=True)
    np.savez_compressed(out, D=np.stack(D), mode=np.array([m[0] for m in meta]),
                        pid=np.array([m[1] for m in meta]), Ta=np.array([m[2] for m in meta]),
                        cols=np.array(COLS))


if __name__ == "__main__":
    main()
