"""Ablation with the RE-TRAINED temperature-free pipeline on the same robustness grid."""
import numpy as np, json, itertools
from sim import *
from control import *
from scipy.stats import wilcoxon
R = json.load(open("res/control_results.json"))
b3 = R["gains"]["B3"]; hn = dict(np.load("res/noT_head.npz"))
grid = list(itertools.product([20.0, 25.0, 30.0], ["soft", "medium", "hard"], [12, 13, 14, 15], [0, 1]))
out = []
for Ta, ob, p, rep in grid:
    L = run_episode(PhysResFFPI(hn, Kp=b3[0], Ki=b3[1], obs_variant="noT"), BANK[p], Ta, OBJ[ob], seed=1000 * p + rep, gap_jitter=0.3)
    a, _ = episode_metrics(L); a.update(Ta=Ta, obj=ob, pouch=p, rep=rep); out.append(a)
x = R["robust"]["B3"]
st = {}
for met in ["iae", "ss_rmse", "overshoot"]:
    A = np.array([r[met] for r in x]); B = np.array([r[met] for r in out]); ok = ~(np.isnan(A) | np.isnan(B))
    st[met] = dict(med_B3=float(np.median(A[ok])), med_noT=float(np.median(B[ok])), p=float(wilcoxon(A[ok], B[ok]).pvalue))
json.dump(dict(robust=out, stats=st), open("res/noT_control.json", "w"), indent=1, default=float)
print(st, "unsettled", sum(r["unsettled"] for r in out), "OS", np.nanmean([r["overshoot"] for r in out]), "ss", np.mean([r["ss_rmse"] for r in out]))
