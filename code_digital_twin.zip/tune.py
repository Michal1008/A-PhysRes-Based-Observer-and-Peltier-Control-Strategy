import numpy as np, sys, twin
from twin import *
def run(over, I_list=(1.0,0.6), Ta=298.15, Imax=float(sys.argv[2]) if len(sys.argv)>2 else 0.4):
    for k,v in over.items(): twin.NOMINAL[k]=v
    P=np.stack([make_pouch(),make_pouch()])
    for u in I_list:
        g=Gripper(P,Ta=Ta,sensor_noise=False); rows=[]
        for k in range(int(70/0.02)):
            t=k*0.02; c = u if t<40 else (-1.0 if t<55 else 0.0)
            g.step(c*Imax); tr=g.truth(); rows.append((tr['h'][0],tr['Tl'][0],tr['Th'][0],g.X[0,2]-273.15,tr['liq'][0]))
        r=np.array(rows); 
        out=" ".join(f"{t}:{r[int(t/0.02)-1,0]:.2f}/{r[int(t/0.02)-1,1]:.0f}/{r[int(t/0.02)-1,4]:.2f}" for t in [3,6,10,15,20,30,40,43,46,50,55,62,70])
        print(f"u={u}: h/Tl/liq  {out}  maxTh={r[:,2].max():.0f} minTs={r[:,3].min():.0f}")
over=eval(sys.argv[1]) if len(sys.argv)>1 else {}
run(over)
