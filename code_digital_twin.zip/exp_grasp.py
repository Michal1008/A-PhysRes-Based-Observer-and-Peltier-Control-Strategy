import numpy as np, json, pickle
from sim import *
from control import *
head = dict(np.load("res/head.npz")); mpc = dict(np.load("res/mpc.npz"))
R = json.load(open("res/control_results.json"))
b2, b3, b4 = R["gains"]["B2"], R["gains"]["B3"], R["gains"]["B4"]
c = R["B1_calib"]; umap = (np.array(c["F"]), np.array(c["u"]))
TEST_POUCH = [12, 13, 14, 15]
CTRL = {"B1": lambda: OpenLoop(umap, c["t_burst"]), "B2": lambda: PID(*b2),
        "B3": lambda: PhysResFFPI(head, Kp=b3[0], Ki=b3[1]),
        "B4": lambda: PhysResMPC(head, mpc, lam=b4[0], Kp=b4[1], Ki=b4[2])}
import time; t00 = time.time()
# ---------------- E5: grasping with disturbances ----------------
OBJECTS = {  # k [N/mm^p], p, gap [mm], F_ref [N], mass [kg], F_break [N]
    "chip": (3.0, 1.0, 0.6, 0.30, 0.002, 0.50),
    "tissue": (0.3, 1.6, 0.4, 0.40, 0.001, 1.50),
    "silicone-soft": (0.8, 1.2, 0.8, 1.00, 0.030, 4.0),
    "silicone-med": (2.5, 1.2, 0.8, 1.00, 0.030, 4.0),
    "silicone-hard": (8.0, 1.2, 0.8, 1.00, 0.030, 4.0),
}
MU = 0.5


def grasp_trial(name, ctrl, P, Ta, seed):
    k, p, gap, Fr, mass, Fb = OBJECTS[name]
    t_d = 40.0
    shift = 0.6 * (Fr / k) ** (1.0 / p) / 2.0   # lateral impulse: object shifts, losing 60 % of the nominal squeeze
    def dist(g, t, gap0):
        if t_d <= t < t_d + 0.02:
            g.gap = gap0 + shift
    prof = lambda t: Fr if t < 70 else 0.0
    L = run_episode(ctrl, P, Ta, (k, p, gap), profile=prof, T_end=75.0, seed=seed, dist=dist, gap_jitter=0.15)
    t, F = L["t"], L["F"]
    need = mass * 9.81 / (2 * MU) * 1.2          # 20 % safety factor against slip
    lift = (t > 25) & (t < 70)                    # lifted after 25 s
    below = (F < need) & lift
    # dropped if force stays below the slip threshold for > 0.5 s while lifted
    run, drop = 0, False
    for b in below:
        run = run + 1 if b else 0
        if run * 0.02 > 0.5:
            drop = True; break
    broken = bool(F[t < 70].max() > Fb)
    i_d = np.searchsorted(t, t_d)
    post = np.abs(F[i_d:] - Fr) <= max(0.1 * Fr, 0.05)
    rec = np.nan
    for j in range(len(post) - 50):
        if post[j:j + 50].all():
            rec = float(t[i_d + j] - t_d); break
    return dict(success=bool(not drop and not broken), drop=drop, broken=broken, peak=float(F[t < 70].max()),
                recovery=rec, Tl_max=float(L["Tl"].max()), ss_err=float(np.mean(np.abs(F[(t > 30) & (t < 40)] - Fr))))


gr = {}
for name in ["B1", "B2", "B3", "B4"]:
    gr[name] = {}
    for obj in OBJECTS:
        rs = [grasp_trial(obj, CTRL[name](), BANK[p], Ta, seed=77 * p + rep)
              for Ta in [20.0, 25.0, 30.0] for p in TEST_POUCH for rep in [0, 1]]
        gr[name][obj] = dict(success=float(np.mean([r["success"] for r in rs])),
                             drop=float(np.mean([r["drop"] for r in rs])),
                             broken=float(np.mean([r["broken"] for r in rs])),
                             peak_med=float(np.median([r["peak"] for r in rs])),
                             peak_max=float(np.max([r["peak"] for r in rs])),
                             recovery_med=float(np.nanmedian([r["recovery"] for r in rs])) if not all(np.isnan([r["recovery"] for r in rs])) else None,
                             recovered=float(np.mean([not np.isnan(r["recovery"]) for r in rs])),
                             n=len(rs), raw=rs)
        print(name, obj, {k: v for k, v in gr[name][obj].items() if k != "raw"}, f"{time.time()-t00:.0f}s", flush=True)
# disturbance trace example
ex = {}
for name in ["B1", "B2", "B3", "B4"]:
    k, p, gap, Fr, mass, Fb = OBJECTS["silicone-med"]
    sh = 0.6 * (Fr / k) ** (1.0 / p) / 2.0
    def dist(g, t, gap0, sh=sh):
        if 40.0 <= t < 40.02:
            g.gap = gap0 + sh
    ex[name] = run_episode(CTRL[name](), BANK[13], 30.0, (k, p, gap), profile=lambda t: 1.0 if t < 70 else 0.0,
                           T_end=75.0, seed=5, dist=dist)
pickle.dump(ex, open("res/traces_dist.pkl", "wb"))
json.dump(gr, open("res/grasp_results.json", "w"), indent=1, default=float)

