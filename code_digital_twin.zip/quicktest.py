import numpy as np, time
from sim import *
from control import *
head=dict(np.load("res/head.npz")); mpc=dict(np.load("res/mpc.npz"))
P=BANK[12]
for name,mk in [("B2",lambda: PID(0.6,0.05)),("B3",lambda: PhysResFFPI(head)),("B4",lambda: PhysResMPC(head,mpc))]:
    t0=time.time(); L=run_episode(mk(),P,25.0,OBJ["medium"]); agg,segs=episode_metrics(L)
    print(name, f"{time.time()-t0:.1f}s", {k:round(v,3) for k,v in agg.items()})
    for s in segs: print("   ",{k:round(v,2) for k,v in s.items()})
